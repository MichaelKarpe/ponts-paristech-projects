#pragma once

#include "outils.h"

const int courbure=carre;

class Trajectoire
{
    std::vector<Point> t; //Vecteur de points
    Point pos; //Position de la grenouille

public:    

    // Constructeur
    Trajectoire();

    // Assesseurs

    //Get
    int size() const;
    Point getPoint(const int &i) const;
    Point getPos() const;
    Point absplan(const int &abs) const;
    int abscurv(const Point &p) const;

    //Set
    void trajectoire1();
    void trajectoire2();

    //Fonctions de tracé
    void traceTrajectoire() const;
};

